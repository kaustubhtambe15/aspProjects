﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Web.UI.WebControls;

namespace StudentRegistation.student
{
    public partial class studentRegistration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();


        }



        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into student values('" + name.Text + "','" + email.Text + "' , '" + number.Text + "' , '" + password.Text + "', '" + address1.Text + "' ,'" + std1.Text + "', 'yes')";
            cmd.ExecuteNonQuery();


            string to = email.Text.Trim(); //To address    
            string from = "kaustubhbt@gmail.com"; //From address    
            MailMessage message = new MailMessage(from, to);

            string mailbody = "Thank you for registering. Your registration has been confirmed.";
            message.Subject = "registration ";
            message.Body = mailbody;
            message.BodyEncoding = System.Text.Encoding.UTF8;
            message.IsBodyHtml = true;
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587); //Gmail smtp    
            System.Net.NetworkCredential basicCredential1 = new

             //                                         // password 
            System.Net.NetworkCredential("kaustubhbt@gmail.com", "");
            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = basicCredential1;
            try
            {
                client.Send(message);
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }


        protected void btnSave_Click(object sender, EventArgs e)
        {
            Response.Redirect("student_login.aspx");
        }
    }
}


