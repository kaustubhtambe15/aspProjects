﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace StudentRegistation.admin
{
    public partial class StudentInfo : System.Web.UI.Page
    {
       
       SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\Documents\Visual Studio 2010\Projects\StudentRegistation\StudentRegistation\App_Data\Database1.mdf;Integrated Security=True;User Instance=True");
       
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            int i = 0;
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            //cmd.CommandText = "select * from student where email='" + username.Text + "'and password='" + password.Text + "'and approve='yes'";
            cmd.CommandText = "select * from student where approve='yes'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            i = Convert.ToInt32(dt.Rows.Count.ToString());
            Label1.Text = i.ToString();
            


            int j = 0;
            SqlCommand cm = con.CreateCommand();
            cm.CommandType = CommandType.Text;
            //cmd.CommandText = "select * from student where email='" + username.Text + "'and password='" + password.Text + "'and approve='yes'";
            cm.CommandText = "select * from student where approve='no'";
            cm.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter da1 = new SqlDataAdapter(cm);
            da1.Fill(dt1);
            j = Convert.ToInt32(dt1.Rows.Count.ToString());
            Label2.Text = j.ToString();

            SqlCommand cmddc = con.CreateCommand();
            cmddc.CommandType = CommandType.Text;
            //cmd.CommandText = "select * from student where email='" + username.Text + "'and password='" + password.Text + "'and approve='yes'";
            cmddc.CommandText = "select * from student";
            cmddc.ExecuteNonQuery();
            DataTable dt2 = new DataTable();
            SqlDataAdapter da2 = new SqlDataAdapter(cmddc);
            da2.Fill(dt2);
            rp1.DataSource = dt2;
            rp1.DataBind();

       }

        
    }
}